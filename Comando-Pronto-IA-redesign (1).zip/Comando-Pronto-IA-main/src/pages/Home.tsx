import { Link } from 'react-router-dom';

const categories = [
  {
    title: 'Redes Sociais',
    description: 'Posts, legendas e conteúdos que engajam e vendem mais.',
    badge: '128 prompts',
    icon: '◎',
    gradient: 'from-fuchsia-500/25 via-pink-500/15 to-slate-950',
  },
  {
    title: 'Vídeos e Reels',
    description: 'Roteiros, ganchos e ideias para vídeos que viralizam.',
    badge: '94 prompts',
    icon: '▶',
    gradient: 'from-violet-500/25 via-purple-500/15 to-slate-950',
  },
  {
    title: 'Anúncios',
    description: 'Copys persuasivas para anúncios que geram resultados.',
    badge: '76 prompts',
    icon: '◈',
    gradient: 'from-blue-500/25 via-cyan-500/10 to-slate-950',
  },
  {
    title: 'Vendas',
    description: 'Ofertas, mensagens e conteúdos que convertem.',
    badge: '65 prompts',
    icon: '✓',
    gradient: 'from-emerald-500/20 via-teal-500/10 to-slate-950',
  },
  {
    title: 'Blog e Artigos',
    description: 'Textos completos e títulos que atraem e posicionam.',
    badge: '52 prompts',
    icon: '✦',
    gradient: 'from-orange-500/20 via-amber-500/10 to-slate-950',
  },
];

const benefits = [
  ['Economize tempo', 'Prompts prontos para usar em segundos'],
  ['Mais resultados', 'Conteúdos que geram engajamento e vendas'],
  ['Personalize', 'Edite e adapte para o seu estilo'],
  ['Atualizações constantes', 'Novos prompts toda semana para você'],
];

export default function Home() {
  return (
    <div className="space-y-8">
      <section className="relative overflow-hidden rounded-[2rem] border border-white/10 bg-slate-950/70 p-7 shadow-2xl shadow-blue-950/30 backdrop-blur md:p-10 lg:p-12">
        <div className="absolute -right-24 -top-24 h-72 w-72 rounded-full bg-blue-600/25 blur-3xl" />
        <div className="absolute -bottom-28 left-1/3 h-80 w-80 rounded-full bg-violet-600/20 blur-3xl" />
        <div className="relative grid gap-10 lg:grid-cols-[1.05fr_0.95fr] lg:items-center">
          <div>
            <span className="inline-flex rounded-full border border-cyan-300/20 bg-cyan-300/10 px-4 py-2 text-xs font-black uppercase tracking-[0.22em] text-cyan-200">
              Mais de 1.000 prompts prontos para você usar
            </span>
            <h1 className="mt-6 max-w-4xl text-5xl font-black tracking-tight text-white md:text-7xl">
              Os prompts certos geram resultados{' '}
              <span className="bg-gradient-to-r from-cyan-300 via-blue-400 to-violet-400 bg-clip-text text-transparent">
                extraordinários.
              </span>
            </h1>
            <p className="mt-6 max-w-2xl text-lg leading-8 text-slate-300">
              Encontre, personalize e aplique comandos prontos para criar conteúdos que vendem e conectam.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link
                to="/gerador"
                className="rounded-full bg-gradient-to-r from-blue-600 to-violet-600 px-7 py-3 font-black text-white shadow-[0_0_30px_rgba(37,99,235,0.45)] transition hover:scale-[1.02]"
              >
                Gerar prompt
              </Link>
              <Link
                to="/biblioteca"
                className="rounded-full border border-white/15 bg-white/10 px-7 py-3 font-black text-white transition hover:bg-white/15"
              >
                Explorar biblioteca
              </Link>
            </div>
          </div>

          <div className="relative min-h-[420px] rounded-[2rem] border border-white/10 bg-gradient-to-br from-white/10 to-white/5 p-6 backdrop-blur">
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_25%_20%,rgba(6,182,212,0.18),transparent_26%),radial-gradient(circle_at_75%_65%,rgba(124,58,237,0.2),transparent_28%)]" />
            <div className="absolute left-1/2 top-1/2 grid h-44 w-44 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-[2rem] border border-cyan-300/25 bg-slate-950/80 text-7xl font-black text-white shadow-[0_0_70px_rgba(37,99,235,0.45)]">
              ⌘
            </div>
            {[
              ['Posts que vendem', 'left-4 top-8 rotate-[-4deg]'],
              ['Roteiros virais', 'right-4 top-24 rotate-[5deg]'],
              ['Anúncios que convertem', 'bottom-20 left-3 rotate-[5deg]'],
              ['Conteúdos que conectam', 'bottom-8 right-6 rotate-[-3deg]'],
            ].map(([label, position]) => (
              <div
                key={label}
                className={`absolute ${position} rounded-2xl border border-white/10 bg-slate-950/75 px-4 py-3 text-sm font-black text-slate-100 shadow-xl backdrop-blur`}
              >
                {label}
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="rounded-[2rem] border border-white/10 bg-slate-950/65 p-5 shadow-xl backdrop-blur">
        <div className="grid gap-3 lg:grid-cols-[1fr_auto] lg:items-center">
          <div className="flex items-center gap-3 rounded-2xl border border-white/10 bg-white/5 px-5 py-4 text-slate-300">
            <span className="text-cyan-300">⌕</span>
            <span>O que você quer criar hoje?</span>
          </div>
          <div className="flex flex-wrap gap-2">
            {['Post para Instagram', 'Roteiro para Reels', 'Anúncio', 'Ver todos'].map((item) => (
              <Link key={item} to={item === 'Ver todos' ? '/biblioteca' : '/gerador'} className="rounded-full border border-white/10 bg-white/10 px-4 py-3 text-sm font-black text-white transition hover:bg-white/15">
                {item}
              </Link>
            ))}
          </div>
        </div>
      </section>

      <section>
        <div className="mb-5 flex items-end justify-between gap-4">
          <div>
            <p className="text-sm font-black uppercase tracking-[0.22em] text-cyan-300">Biblioteca</p>
            <h2 className="mt-2 text-3xl font-black tracking-tight text-white md:text-4xl">Categorias populares</h2>
          </div>
          <Link to="/biblioteca" className="hidden font-black text-cyan-300 hover:text-cyan-200 md:inline-flex">
            Ver todas as categorias →
          </Link>
        </div>
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-5">
          {categories.map((category) => (
            <article
              key={category.title}
              className={`group min-h-64 rounded-[1.7rem] border border-white/10 bg-gradient-to-br ${category.gradient} p-5 shadow-xl transition duration-300 hover:-translate-y-1 hover:border-cyan-300/30 hover:shadow-blue-950/40`}
            >
              <div className="grid h-12 w-12 place-items-center rounded-2xl border border-white/10 bg-white/10 text-2xl text-white">
                {category.icon}
              </div>
              <h3 className="mt-5 text-xl font-black tracking-tight text-white">{category.title}</h3>
              <p className="mt-3 text-sm leading-6 text-slate-300">{category.description}</p>
              <span className="mt-5 inline-flex rounded-full border border-white/10 bg-white/10 px-3 py-1 text-xs font-black uppercase tracking-wide text-cyan-100">
                {category.badge}
              </span>
            </article>
          ))}
        </div>
      </section>

      <section className="grid gap-4 rounded-[2rem] border border-white/10 bg-white/[0.06] p-5 shadow-xl backdrop-blur md:grid-cols-2 xl:grid-cols-4">
        {benefits.map(([title, text]) => (
          <div key={title} className="rounded-2xl border border-white/10 bg-slate-950/50 p-5">
            <h3 className="font-black text-white">{title}</h3>
            <p className="mt-2 text-sm leading-6 text-slate-400">{text}</p>
          </div>
        ))}
      </section>
    </div>
  );
}
